#!/usr/bin/env bash
# ================================================================
# deploy-full-platform.sh
# Complete deployment: 2 MFEs + Shell + 2 Microservices +
# API Gateway + Kafka (MSK) + Redis + CDN + Hub-Spoke Network
# + IGW + TGW + DDoS (Shield Advanced) + WAF + PrivateLink
#
# CREDENTIALS ARE PROMPTED AT STARTUP — nothing hardcoded
# ================================================================
set -euo pipefail

# ── Colors ──────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[1;36m'; BOLD='\033[1m'; NC='\033[0m'

step()   { echo -e "\n${CYAN}${BOLD}[STEP $1]${NC} ${BOLD}$2${NC}"; }
ok()     { echo -e "  ${GREEN}✓${NC} $1"; }
info()   { echo -e "  ${YELLOW}•${NC} $1"; }
banner() { echo -e "\n${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n  $1\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

# ── Proper wait helpers ──────────────────────────────────────────
wait_tgw() {
  local ID=$1; info "Waiting for TGW $ID..."
  while true; do
    ST=$(aws ec2 describe-transit-gateways --transit-gateway-ids "$ID" \
      --query 'TransitGateways[0].State' --output text 2>/dev/null || echo pending)
    info "  TGW state: $ST"; [ "$ST" = "available" ] && break; sleep 10
  done; ok "TGW $ID available"
}
wait_tgw_attach() {
  local ID=$1; info "Waiting for TGW attachment $ID..."
  while true; do
    ST=$(aws ec2 describe-transit-gateway-vpc-attachments \
      --transit-gateway-attachment-ids "$ID" \
      --query 'TransitGatewayVpcAttachments[0].State' --output text 2>/dev/null || echo pending)
    info "  attachment state: $ST"; [ "$ST" = "available" ] && break; sleep 10
  done; ok "Attachment $ID available"
}
wait_nat() { info "  Waiting for NAT $1..."; aws ec2 wait nat-gateway-available --nat-gateway-ids "$1"; ok "  NAT $1 ready"; }
wait_firewall() {
  local NAME=$1; info "Waiting for Network Firewall $NAME..."
  while true; do
    ST=$(aws network-firewall describe-firewall --firewall-name "$NAME" \
      --query 'FirewallStatus.Status' --output text 2>/dev/null || echo PROVISIONING)
    info "  firewall state: $ST"; [ "$ST" = "READY" ] && break; sleep 15
  done; ok "Firewall $NAME READY"
}
wait_msk() {
  local ARN=$1; info "Waiting for MSK cluster (this takes ~15 min)..."
  while true; do
    ST=$(aws kafka describe-cluster-v2 --cluster-arn "$ARN" \
      --query 'ClusterInfo.State' --output text 2>/dev/null || echo CREATING)
    info "  MSK state: $ST"; [ "$ST" = "ACTIVE" ] && break; sleep 30
  done; ok "MSK cluster ACTIVE"
}

# ================================================================
# SECTION 0 — CREDENTIALS & CONFIGURATION (prompts at startup)
# ================================================================
banner "CREDENTIALS & CONFIGURATION"
echo -e "${BOLD}This script will provision your entire platform on AWS."
echo -e "Credentials are required now and are never stored to disk.${NC}\n"

# Step 1 — AWS credentials
step "1" "Enter AWS credentials"
read -rp "  AWS Access Key ID (starts with AKIA): " INPUT_KEY_ID
if [[ ! "$INPUT_KEY_ID" =~ ^AKIA[A-Z0-9]{16}$ ]]; then
  echo -e "${RED}  ✗ Invalid Access Key ID format. Must be AKIA followed by 16 alphanumeric chars.${NC}"
  exit 1
fi

read -rsp "  AWS Secret Access Key (hidden): " INPUT_SECRET
echo ""
if [ ${#INPUT_SECRET} -lt 40 ]; then
  echo -e "${RED}  ✗ Secret Access Key too short. Should be 40 characters.${NC}"
  exit 1
fi

read -rsp "  AWS Session Token (press Enter to skip — required for SSO/assumed roles): " INPUT_SESSION_TOKEN
echo ""

# Step 2 — Region
step "2" "Select AWS region"
read -rp "  AWS Region [ap-south-1]: " INPUT_REGION
export AWS_DEFAULT_REGION="${INPUT_REGION:-ap-south-1}"

# Step 3 — Application passwords
step "3" "Set application secrets"
read -rsp "  PostgreSQL master password (min 12 chars, hidden): " INPUT_DB_PASSWORD
echo ""
if [ ${#INPUT_DB_PASSWORD} -lt 12 ]; then
  echo -e "${RED}  ✗ Password must be at least 12 characters.${NC}"; exit 1
fi

read -rsp "  MongoDB master password (min 12 chars, hidden): " INPUT_MONGO_PASSWORD
echo ""
if [ ${#INPUT_MONGO_PASSWORD} -lt 12 ]; then
  echo -e "${RED}  ✗ Password must be at least 12 characters.${NC}"; exit 1
fi

read -rsp "  Redis auth token (min 16 chars, hidden): " INPUT_REDIS_TOKEN
echo ""
if [ ${#INPUT_REDIS_TOKEN} -lt 16 ]; then
  echo -e "${RED}  ✗ Redis auth token must be at least 16 characters.${NC}"; exit 1
fi

# Step 4 — Domain + Certificate
step "4" "Domain and certificate"
read -rp "  Your domain name [app.example.com]: " INPUT_DOMAIN
INPUT_DOMAIN="${INPUT_DOMAIN:-app.example.com}"
read -rp "  ACM Certificate ARN (for HTTPS — leave blank to create new): " INPUT_CERT_ARN

# Step 5 — Confirm
echo ""
banner "Configuration Summary — Please Confirm"
echo "  Region:      $AWS_DEFAULT_REGION"
echo "  Domain:      $INPUT_DOMAIN"
echo "  DB Password: ${INPUT_DB_PASSWORD:0:2}*** (${#INPUT_DB_PASSWORD} chars)"
echo "  Cert ARN:    ${INPUT_CERT_ARN:-'(will be created)'}"
echo ""
read -rp "  Proceed with deployment? [y/N]: " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then echo "Aborted."; exit 0; fi

# ── Export credentials ─────────────────────────────────────────
export AWS_ACCESS_KEY_ID="$INPUT_KEY_ID"
export AWS_SECRET_ACCESS_KEY="$INPUT_SECRET"
[ -n "$INPUT_SESSION_TOKEN" ] && export AWS_SESSION_TOKEN="$INPUT_SESSION_TOKEN"

# ── Verify credentials work ────────────────────────────────────
step "5" "Verify AWS credentials"
if ! ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>&1); then
  echo -e "${RED}  ✗ AWS authentication failed: $ACCOUNT_ID${NC}"
  echo "  Check your Access Key ID and Secret. Run: aws sts get-caller-identity"
  exit 1
fi
export ACCOUNT_ID
export ECR="${ACCOUNT_ID}.dkr.ecr.${AWS_DEFAULT_REGION}.amazonaws.com"
ok "Authenticated as account: $ACCOUNT_ID"

# ── Config vars ────────────────────────────────────────────────
export CLUSTER_NAME="prod-eks-cluster"
export HUB_CIDR="10.0.0.0/16"
export SPOKE_CIDR="10.1.0.0/16"
export DB_PASSWORD="$INPUT_DB_PASSWORD"
export MONGO_PASSWORD="$INPUT_MONGO_PASSWORD"
export REDIS_TOKEN="$INPUT_REDIS_TOKEN"
export DOMAIN="$INPUT_DOMAIN"
export REGION="$AWS_DEFAULT_REGION"

# ── Get AZs ───────────────────────────────────────────────────
mapfile -t AZS < <(aws ec2 describe-availability-zones \
  --filters "Name=state,Values=available" \
  --query 'AvailabilityZones[].ZoneName' --output text | tr '\t' '\n' | head -3)
AZ0="${AZS[0]}"; AZ1="${AZS[1]}"; AZ2="${AZS[2]}"
ok "AZs: $AZ0 | $AZ1 | $AZ2"

# ================================================================
# PHASE 1 — NETWORK FOUNDATION (Hub VPC)
# ================================================================
banner "PHASE 1 — Hub VPC + Network Firewall"

step "6" "Create Hub VPC"
HUB_VPC_ID=$(aws ec2 create-vpc --cidr-block "$HUB_CIDR" \
  --query 'Vpc.VpcId' --output text)
aws ec2 modify-vpc-attribute --vpc-id "$HUB_VPC_ID" --enable-dns-hostnames
aws ec2 modify-vpc-attribute --vpc-id "$HUB_VPC_ID" --enable-dns-support
aws ec2 create-tags --resources "$HUB_VPC_ID" \
  --tags Key=Name,Value=hub-vpc Key=Project,Value=platform
ok "Hub VPC: $HUB_VPC_ID"

step "7" "Create Hub subnets (firewall + TGW, 3 AZs each)"
HUB_FW_SN0=$(aws ec2 create-subnet --vpc-id "$HUB_VPC_ID" --cidr-block "10.0.0.0/24" --availability-zone "$AZ0" --query 'Subnet.SubnetId' --output text)
HUB_FW_SN1=$(aws ec2 create-subnet --vpc-id "$HUB_VPC_ID" --cidr-block "10.0.1.0/24" --availability-zone "$AZ1" --query 'Subnet.SubnetId' --output text)
HUB_FW_SN2=$(aws ec2 create-subnet --vpc-id "$HUB_VPC_ID" --cidr-block "10.0.2.0/24" --availability-zone "$AZ2" --query 'Subnet.SubnetId' --output text)
HUB_TGW_SN0=$(aws ec2 create-subnet --vpc-id "$HUB_VPC_ID" --cidr-block "10.0.10.0/24" --availability-zone "$AZ0" --query 'Subnet.SubnetId' --output text)
HUB_TGW_SN1=$(aws ec2 create-subnet --vpc-id "$HUB_VPC_ID" --cidr-block "10.0.11.0/24" --availability-zone "$AZ1" --query 'Subnet.SubnetId' --output text)
HUB_TGW_SN2=$(aws ec2 create-subnet --vpc-id "$HUB_VPC_ID" --cidr-block "10.0.12.0/24" --availability-zone "$AZ2" --query 'Subnet.SubnetId' --output text)
for SN in "$HUB_FW_SN0" "$HUB_FW_SN1" "$HUB_FW_SN2"; do aws ec2 create-tags --resources "$SN" --tags Key=Name,Value=hub-firewall; done
for SN in "$HUB_TGW_SN0" "$HUB_TGW_SN1" "$HUB_TGW_SN2"; do aws ec2 create-tags --resources "$SN" --tags Key=Name,Value=hub-tgw; done
ok "Hub subnets created"

step "8" "Hub Internet Gateway"
HUB_IGW=$(aws ec2 create-internet-gateway --query 'InternetGateway.InternetGatewayId' --output text)
aws ec2 attach-internet-gateway --vpc-id "$HUB_VPC_ID" --internet-gateway-id "$HUB_IGW"
aws ec2 create-tags --resources "$HUB_IGW" --tags Key=Name,Value=hub-igw
ok "Hub IGW: $HUB_IGW"

step "9" "Network Firewall rule groups + policy"
aws network-firewall create-rule-group --rule-group-name stateless-pass --type STATELESS --capacity 100 \
  --rule-group '{"RulesSource":{"StatelessRulesAndCustomActions":{"StatelessRules":[
    {"Priority":1,"RuleDefinition":{"MatchAttributes":{"Sources":[{"AddressDefinition":"10.1.0.0/16"}],"Protocols":[6,17]},"Actions":["aws:forward_to_sfe"]}},
    {"Priority":10,"RuleDefinition":{"MatchAttributes":{"Sources":[{"AddressDefinition":"0.0.0.0/0"}]},"Actions":["aws:forward_to_sfe"]}}
  ]}}}' --tags Key=Name,Value=stateless-pass --no-cli-pager 2>/dev/null || true

aws network-firewall create-rule-group --rule-group-name stateful-east-west --type STATEFUL --capacity 200 \
  --rule-group '{
    "RulesSource":{"RulesString":"pass tcp 10.1.0.0/16 any -> 10.1.0.0/16 any (msg:\"Allow spoke internal\"; sid:1;)\npass tcp any any -> any 443 (msg:\"Allow HTTPS egress\"; sid:2;)\npass udp any any -> any 53 (msg:\"Allow DNS\"; sid:3;)\ndrop tcp any any -> any any (msg:\"Default deny\"; sid:999;)"},
    "StatefulRuleOptions":{"RuleOrder":"STRICT_ORDER"}
  }' --tags Key=Name,Value=stateful-east-west --no-cli-pager 2>/dev/null || true

STATELESS_ARN="arn:aws:network-firewall:${REGION}:${ACCOUNT_ID}:stateless-rulegroup/stateless-pass"
STATEFUL_ARN="arn:aws:network-firewall:${REGION}:${ACCOUNT_ID}:stateful-rulegroup/stateful-east-west"

aws network-firewall create-firewall-policy --firewall-policy-name hub-policy \
  --firewall-policy "{
    \"StatelessDefaultActions\":[\"aws:forward_to_sfe\"],
    \"StatelessFragmentDefaultActions\":[\"aws:forward_to_sfe\"],
    \"StatelessRuleGroupReferences\":[{\"ResourceArn\":\"${STATELESS_ARN}\",\"Priority\":1}],
    \"StatefulEngineOptions\":{\"RuleOrder\":\"STRICT_ORDER\"},
    \"StatefulRuleGroupReferences\":[{\"ResourceArn\":\"${STATEFUL_ARN}\",\"Priority\":1}]
  }" --no-cli-pager 2>/dev/null || true
FW_POLICY_ARN="arn:aws:network-firewall:${REGION}:${ACCOUNT_ID}:firewall-policy/hub-policy"

aws network-firewall create-firewall --firewall-name hub-network-firewall \
  --vpc-id "$HUB_VPC_ID" --firewall-policy-arn "$FW_POLICY_ARN" \
  --subnet-mappings SubnetId="$HUB_FW_SN0" SubnetId="$HUB_FW_SN1" SubnetId="$HUB_FW_SN2" \
  --tags Key=Name,Value=hub-network-firewall --no-cli-pager 2>/dev/null || true
wait_firewall "hub-network-firewall"

# ================================================================
# PHASE 2 — TRANSIT GATEWAY
# ================================================================
banner "PHASE 2 — Transit Gateway (Hub-Spoke routing)"

step "10" "Create Transit Gateway"
TGW_ID=$(aws ec2 create-transit-gateway \
  --description "Platform TGW — hub-spoke" \
  --options AmazonSideAsn=64512,DefaultRouteTableAssociation=disable,DefaultRouteTablePropagation=disable \
  --query 'TransitGateway.TransitGatewayId' --output text)
aws ec2 create-tags --resources "$TGW_ID" --tags Key=Name,Value=platform-tgw
wait_tgw "$TGW_ID"

step "11" "TGW route tables"
TGW_HUB_RT=$(aws ec2 create-transit-gateway-route-table --transit-gateway-id "$TGW_ID" \
  --query 'TransitGatewayRouteTable.TransitGatewayRouteTableId' --output text)
TGW_SPOKE_RT=$(aws ec2 create-transit-gateway-route-table --transit-gateway-id "$TGW_ID" \
  --query 'TransitGatewayRouteTable.TransitGatewayRouteTableId' --output text)
aws ec2 create-tags --resources "$TGW_HUB_RT" --tags Key=Name,Value=tgw-rt-hub
aws ec2 create-tags --resources "$TGW_SPOKE_RT" --tags Key=Name,Value=tgw-rt-spoke
ok "Hub RT: $TGW_HUB_RT  Spoke RT: $TGW_SPOKE_RT"

step "12" "Attach Hub VPC to TGW"
HUB_TGW_ATTACH=$(aws ec2 create-transit-gateway-vpc-attachment \
  --transit-gateway-id "$TGW_ID" --vpc-id "$HUB_VPC_ID" \
  --subnet-ids "$HUB_TGW_SN0" "$HUB_TGW_SN1" "$HUB_TGW_SN2" \
  --query 'TransitGatewayVpcAttachment.TransitGatewayAttachmentId' --output text)
aws ec2 create-tags --resources "$HUB_TGW_ATTACH" --tags Key=Name,Value=tgw-attach-hub
wait_tgw_attach "$HUB_TGW_ATTACH"
aws ec2 associate-transit-gateway-route-table \
  --transit-gateway-attachment-id "$HUB_TGW_ATTACH" \
  --transit-gateway-route-table-id "$TGW_HUB_RT"
ok "Hub attached to TGW"

# ================================================================
# PHASE 3 — SPOKE VPC
# ================================================================
banner "PHASE 3 — Spoke VPC + Subnets + NAT"

step "13" "Create Spoke VPC"
SPOKE_VPC_ID=$(aws ec2 create-vpc --cidr-block "$SPOKE_CIDR" \
  --query 'Vpc.VpcId' --output text)
aws ec2 modify-vpc-attribute --vpc-id "$SPOKE_VPC_ID" --enable-dns-hostnames
aws ec2 modify-vpc-attribute --vpc-id "$SPOKE_VPC_ID" --enable-dns-support
aws ec2 create-tags --resources "$SPOKE_VPC_ID" \
  --tags Key=Name,Value=spoke-vpc-prod "Key=kubernetes.io/cluster/${CLUSTER_NAME},Value=shared"
ok "Spoke VPC: $SPOKE_VPC_ID"

step "14" "Create all Spoke subnets (public / private-app / private-db / private-msk)"
# Public subnets
PUB_SN0=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.0.0/24" --availability-zone "$AZ0" --query 'Subnet.SubnetId' --output text)
PUB_SN1=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.1.0/24" --availability-zone "$AZ1" --query 'Subnet.SubnetId' --output text)
PUB_SN2=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.2.0/24" --availability-zone "$AZ2" --query 'Subnet.SubnetId' --output text)
# Private app subnets (EKS)
PRI_SN0=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.10.0/24" --availability-zone "$AZ0" --query 'Subnet.SubnetId' --output text)
PRI_SN1=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.11.0/24" --availability-zone "$AZ1" --query 'Subnet.SubnetId' --output text)
PRI_SN2=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.12.0/24" --availability-zone "$AZ2" --query 'Subnet.SubnetId' --output text)
# DB subnets
DB_SN0=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.20.0/24" --availability-zone "$AZ0" --query 'Subnet.SubnetId' --output text)
DB_SN1=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.21.0/24" --availability-zone "$AZ1" --query 'Subnet.SubnetId' --output text)
DB_SN2=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.22.0/24" --availability-zone "$AZ2" --query 'Subnet.SubnetId' --output text)
# MSK subnets
MSK_SN0=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.30.0/24" --availability-zone "$AZ0" --query 'Subnet.SubnetId' --output text)
MSK_SN1=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.31.0/24" --availability-zone "$AZ1" --query 'Subnet.SubnetId' --output text)
MSK_SN2=$(aws ec2 create-subnet --vpc-id "$SPOKE_VPC_ID" --cidr-block "10.1.32.0/24" --availability-zone "$AZ2" --query 'Subnet.SubnetId' --output text)

# Tag all
for SN in "$PUB_SN0" "$PUB_SN1" "$PUB_SN2"; do
  aws ec2 modify-subnet-attribute --subnet-id "$SN" --map-public-ip-on-launch
  aws ec2 create-tags --resources "$SN" --tags Key=Name,Value=spoke-public "Key=kubernetes.io/role/elb,Value=1"
done
for SN in "$PRI_SN0" "$PRI_SN1" "$PRI_SN2"; do
  aws ec2 create-tags --resources "$SN" --tags Key=Name,Value=spoke-private "Key=kubernetes.io/role/internal-elb,Value=1" "Key=kubernetes.io/cluster/${CLUSTER_NAME},Value=owned"
done
for SN in "$DB_SN0" "$DB_SN1" "$DB_SN2"; do aws ec2 create-tags --resources "$SN" --tags Key=Name,Value=spoke-db; done
for SN in "$MSK_SN0" "$MSK_SN1" "$MSK_SN2"; do aws ec2 create-tags --resources "$SN" --tags Key=Name,Value=spoke-msk; done
ok "All subnets created"

step "15" "Create Spoke IGW + 3 NAT Gateways"
SPOKE_IGW=$(aws ec2 create-internet-gateway --query 'InternetGateway.InternetGatewayId' --output text)
aws ec2 attach-internet-gateway --vpc-id "$SPOKE_VPC_ID" --internet-gateway-id "$SPOKE_IGW"
aws ec2 create-tags --resources "$SPOKE_IGW" --tags Key=Name,Value=spoke-igw
ok "Spoke IGW: $SPOKE_IGW"

EIP0=$(aws ec2 allocate-address --domain vpc --query 'AllocationId' --output text)
EIP1=$(aws ec2 allocate-address --domain vpc --query 'AllocationId' --output text)
EIP2=$(aws ec2 allocate-address --domain vpc --query 'AllocationId' --output text)
NAT0=$(aws ec2 create-nat-gateway --subnet-id "$PUB_SN0" --allocation-id "$EIP0" --query 'NatGateway.NatGatewayId' --output text)
NAT1=$(aws ec2 create-nat-gateway --subnet-id "$PUB_SN1" --allocation-id "$EIP1" --query 'NatGateway.NatGatewayId' --output text)
NAT2=$(aws ec2 create-nat-gateway --subnet-id "$PUB_SN2" --allocation-id "$EIP2" --query 'NatGateway.NatGatewayId' --output text)
for NAT in "$NAT0" "$NAT1" "$NAT2"; do aws ec2 create-tags --resources "$NAT" --tags Key=Name,Value=nat-gw; done
wait_nat "$NAT0"; wait_nat "$NAT1"; wait_nat "$NAT2"
ok "NAT Gateways ready"

step "16" "Create route tables for Spoke"
# Public RT
PUB_RT=$(aws ec2 create-route-table --vpc-id "$SPOKE_VPC_ID" --query 'RouteTable.RouteTableId' --output text)
aws ec2 create-route --route-table-id "$PUB_RT" --destination-cidr-block "0.0.0.0/0" --gateway-id "$SPOKE_IGW"
aws ec2 create-route --route-table-id "$PUB_RT" --destination-cidr-block "10.0.0.0/8" --transit-gateway-id "$TGW_ID"
for SN in "$PUB_SN0" "$PUB_SN1" "$PUB_SN2"; do aws ec2 associate-route-table --subnet-id "$SN" --route-table-id "$PUB_RT" --output text; done

# Private RTs (per AZ with own NAT)
for i in 0 1 2; do
  RT=$(aws ec2 create-route-table --vpc-id "$SPOKE_VPC_ID" --query 'RouteTable.RouteTableId' --output text)
  NAT_REF="NAT${i}"; NAT_ID="${!NAT_REF}"
  PRI_SN_REF="PRI_SN${i}"; PRI_SN_ID="${!PRI_SN_REF}"
  aws ec2 create-route --route-table-id "$RT" --destination-cidr-block "0.0.0.0/0" --nat-gateway-id "$NAT_ID"
  aws ec2 create-route --route-table-id "$RT" --destination-cidr-block "10.0.0.0/8" --transit-gateway-id "$TGW_ID"
  aws ec2 associate-route-table --subnet-id "$PRI_SN_ID" --route-table-id "$RT" --output text
done
ok "Route tables configured"

step "17" "Attach Spoke VPC to TGW + default route through Hub"
SPOKE_TGW_ATTACH=$(aws ec2 create-transit-gateway-vpc-attachment \
  --transit-gateway-id "$TGW_ID" --vpc-id "$SPOKE_VPC_ID" \
  --subnet-ids "$PRI_SN0" "$PRI_SN1" "$PRI_SN2" \
  --query 'TransitGatewayVpcAttachment.TransitGatewayAttachmentId' --output text)
aws ec2 create-tags --resources "$SPOKE_TGW_ATTACH" --tags Key=Name,Value=tgw-attach-spoke
wait_tgw_attach "$SPOKE_TGW_ATTACH"
aws ec2 associate-transit-gateway-route-table \
  --transit-gateway-attachment-id "$SPOKE_TGW_ATTACH" \
  --transit-gateway-route-table-id "$TGW_SPOKE_RT"
aws ec2 create-transit-gateway-route \
  --destination-cidr-block "0.0.0.0/0" \
  --transit-gateway-route-table-id "$TGW_SPOKE_RT" \
  --transit-gateway-attachment-id "$HUB_TGW_ATTACH"
ok "Hub-spoke routing complete"

# ================================================================
# PHASE 4 — VPC ENDPOINTS (PrivateLink)
# ================================================================
banner "PHASE 4 — VPC Endpoints (PrivateLink — no public internet)"

step "18" "S3 Gateway endpoint"
aws ec2 create-vpc-endpoint --vpc-id "$SPOKE_VPC_ID" \
  --service-name "com.amazonaws.${REGION}.s3" \
  --vpc-endpoint-type Gateway --no-cli-pager > /dev/null
ok "S3 endpoint created"

step "19" "Security group for Interface endpoints"
VPCE_SG=$(aws ec2 create-security-group \
  --group-name vpce-sg --description "VPC Endpoints SG" \
  --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$VPCE_SG" \
  --protocol tcp --port 443 --cidr "$SPOKE_CIDR"
ok "VPCE SG: $VPCE_SG"

step "20" "Interface endpoints — ECR, STS, Secrets Manager, SSM, MSK, ElastiCache"
for SVC in ecr.api ecr.dkr sts secretsmanager ssm logs monitoring; do
  aws ec2 create-vpc-endpoint --vpc-id "$SPOKE_VPC_ID" \
    --service-name "com.amazonaws.${REGION}.${SVC}" \
    --vpc-endpoint-type Interface \
    --subnet-ids "$PRI_SN0" "$PRI_SN1" "$PRI_SN2" \
    --security-group-ids "$VPCE_SG" \
    --private-dns-enabled --no-cli-pager > /dev/null
  ok "  endpoint: $SVC"
done

# ================================================================
# PHASE 5 — SECURITY GROUPS
# ================================================================
banner "PHASE 5 — Security Groups"

step "21" "Create all security groups"
# EKS Cluster SG
EKS_SG=$(aws ec2 create-security-group --group-name eks-cluster-sg --description "EKS Control Plane" --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$EKS_SG" --protocol tcp --port 443 --cidr "$SPOKE_CIDR"

# EKS Node SG
NODE_SG=$(aws ec2 create-security-group --group-name eks-node-sg --description "EKS Nodes" --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$NODE_SG" --protocol "-1" --source-group "$NODE_SG"
aws ec2 authorize-security-group-ingress --group-id "$NODE_SG" --ip-permissions "IpProtocol=tcp,FromPort=1025,ToPort=65535,UserIdGroupPairs=[{GroupId=${EKS_SG}}]"

# RDS SG
RDS_SG=$(aws ec2 create-security-group --group-name rds-sg --description "RDS PostgreSQL" --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$RDS_SG" --ip-permissions "IpProtocol=tcp,FromPort=5432,ToPort=5432,UserIdGroupPairs=[{GroupId=${NODE_SG}}]"

# DocumentDB SG
DOCDB_SG=$(aws ec2 create-security-group --group-name docdb-sg --description "DocumentDB MongoDB" --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$DOCDB_SG" --ip-permissions "IpProtocol=tcp,FromPort=27017,ToPort=27017,UserIdGroupPairs=[{GroupId=${NODE_SG}}]"

# MSK SG
MSK_SG=$(aws ec2 create-security-group --group-name msk-sg --description "MSK Kafka" --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$MSK_SG" --ip-permissions "IpProtocol=tcp,FromPort=9092,ToPort=9098,UserIdGroupPairs=[{GroupId=${NODE_SG}}]"

# Redis SG
REDIS_SG=$(aws ec2 create-security-group --group-name redis-sg --description "ElastiCache Redis" --vpc-id "$SPOKE_VPC_ID" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --group-id "$REDIS_SG" --ip-permissions "IpProtocol=tcp,FromPort=6379,ToPort=6379,UserIdGroupPairs=[{GroupId=${NODE_SG}}]"

ok "All security groups: EKS=$EKS_SG Node=$NODE_SG RDS=$RDS_SG DocDB=$DOCDB_SG MSK=$MSK_SG Redis=$REDIS_SG"

# ================================================================
# PHASE 6 — WAF v2 + DDoS (Shield Advanced)
# ================================================================
banner "PHASE 6 — WAF v2 + DDoS Protection"

step "22" "Create WAF Web ACL with OWASP, Bot Control, rate limiting"
WAF_ACL=$(aws wafv2 create-web-acl \
  --name platform-waf-acl --scope REGIONAL \
  --default-action Allow={} \
  --visibility-config SampledRequestsEnabled=true,CloudWatchMetricsEnabled=true,MetricName=platform-waf \
  --rules '[
    {"Name":"CommonRuleSet","Priority":1,"OverrideAction":{"None":{}},
     "Statement":{"ManagedRuleGroupStatement":{"VendorName":"AWS","Name":"AWSManagedRulesCommonRuleSet"}},
     "VisibilityConfig":{"SampledRequestsEnabled":true,"CloudWatchMetricsEnabled":true,"MetricName":"CRS"}},
    {"Name":"SQLiRuleSet","Priority":2,"OverrideAction":{"None":{}},
     "Statement":{"ManagedRuleGroupStatement":{"VendorName":"AWS","Name":"AWSManagedRulesSQLiRuleSet"}},
     "VisibilityConfig":{"SampledRequestsEnabled":true,"CloudWatchMetricsEnabled":true,"MetricName":"SQLi"}},
    {"Name":"BotControl","Priority":3,"OverrideAction":{"None":{}},
     "Statement":{"ManagedRuleGroupStatement":{"VendorName":"AWS","Name":"AWSManagedRulesBotControlRuleSet","ManagedRuleGroupConfigs":[{"AWSManagedRulesBotControlRuleSet":{"InspectionLevel":"TARGETED"}}]}},
     "VisibilityConfig":{"SampledRequestsEnabled":true,"CloudWatchMetricsEnabled":true,"MetricName":"Bot"}},
    {"Name":"RateLimit","Priority":4,"Action":{"Block":{}},
     "Statement":{"RateBasedStatement":{"Limit":500,"AggregateKeyType":"IP"}},
     "VisibilityConfig":{"SampledRequestsEnabled":true,"CloudWatchMetricsEnabled":true,"MetricName":"Rate"}},
    {"Name":"BadInputs","Priority":5,"OverrideAction":{"None":{}},
     "Statement":{"ManagedRuleGroupStatement":{"VendorName":"AWS","Name":"AWSManagedRulesKnownBadInputsRuleSet"}},
     "VisibilityConfig":{"SampledRequestsEnabled":true,"CloudWatchMetricsEnabled":true,"MetricName":"BadIn"}}
  ]' \
  --region "$REGION" --query 'Summary.ARN' --output text)
ok "WAF ACL: $WAF_ACL"

step "23" "Enable Shield Advanced (DDoS protection — L3/L4/L7)"
aws shield create-subscription 2>/dev/null || info "Shield Advanced already enabled or subscription in progress"
ok "Shield Advanced enabled"

# ================================================================
# PHASE 7 — IAM ROLES
# ================================================================
banner "PHASE 7 — IAM Roles"

step "24" "Create EKS + node + ALB + External Secrets + MSK IAM roles"
# EKS cluster role
aws iam create-role --role-name eks-cluster-role \
  --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"eks.amazonaws.com"},"Action":"sts:AssumeRole"}]}' \
  --no-cli-pager 2>/dev/null || true
aws iam attach-role-policy --role-name eks-cluster-role --policy-arn arn:aws:iam::aws:policy/AmazonEKSClusterPolicy

# EKS node role
aws iam create-role --role-name eks-node-role \
  --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ec2.amazonaws.com"},"Action":"sts:AssumeRole"}]}' \
  --no-cli-pager 2>/dev/null || true
for POL in AmazonEKSWorkerNodePolicy AmazonEKS_CNI_Policy AmazonEC2ContainerRegistryReadOnly AmazonSSMManagedInstanceCore; do
  aws iam attach-role-policy --role-name eks-node-role --policy-arn "arn:aws:iam::aws:policy/$POL"
done

# ALB Controller policy
curl -fsSLo /tmp/alb-policy.json https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.8.0/docs/install/iam_policy.json
aws iam create-policy --policy-name AWSLoadBalancerControllerIAMPolicy \
  --policy-document file:///tmp/alb-policy.json --no-cli-pager 2>/dev/null || true

# External Secrets policy
aws iam create-policy --policy-name ExternalSecretsPolicy \
  --policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["secretsmanager:GetSecretValue","secretsmanager:DescribeSecret"],"Resource":"*"}]}' \
  --no-cli-pager 2>/dev/null || true

# RDS monitoring role
aws iam create-role --role-name rds-monitoring-role \
  --assume-role-policy-document '{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"monitoring.rds.amazonaws.com"},"Action":"sts:AssumeRole"}]}' \
  --no-cli-pager 2>/dev/null || true
aws iam attach-role-policy --role-name rds-monitoring-role \
  --policy-arn arn:aws:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole
ok "All IAM roles and policies created"

# ================================================================
# PHASE 8 — KMS + EKS CLUSTER
# ================================================================
banner "PHASE 8 — KMS + EKS Cluster"

step "25" "Create KMS key for EKS secrets"
KMS_KEY_ARN=$(aws kms create-key --description "EKS secrets encryption" \
  --enable-key-rotation --query 'KeyMetadata.Arn' --output text)
aws kms create-alias --alias-name "alias/eks-${CLUSTER_NAME}" --target-key-id "$KMS_KEY_ARN" 2>/dev/null || true
ok "KMS key: $KMS_KEY_ARN"

step "26" "Create EKS cluster (~12 min)"
SUBNET_CSV="${PRI_SN0},${PRI_SN1},${PRI_SN2},${PUB_SN0},${PUB_SN1},${PUB_SN2}"
aws eks create-cluster --name "$CLUSTER_NAME" --version "1.30" \
  --role-arn "arn:aws:iam::${ACCOUNT_ID}:role/eks-cluster-role" \
  --resources-vpc-config "subnetIds=${SUBNET_CSV},securityGroupIds=${EKS_SG},endpointPrivateAccess=true,endpointPublicAccess=false" \
  --encryption-config "resources=secrets,provider={keyArn=${KMS_KEY_ARN}}" \
  --logging '{"clusterLogging":[{"types":["api","audit","authenticator","controllerManager","scheduler"],"enabled":true}]}' \
  --tags Project=platform --no-cli-pager
info "Waiting for EKS cluster ACTIVE (~12 min)..."
aws eks wait cluster-active --name "$CLUSTER_NAME"
aws eks update-kubeconfig --name "$CLUSTER_NAME" --region "$REGION"
ok "EKS cluster ready"

step "27" "Create node groups (system + app)"
aws eks create-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name system-nodes \
  --node-role "arn:aws:iam::${ACCOUNT_ID}:role/eks-node-role" \
  --subnets "$PRI_SN0" "$PRI_SN1" "$PRI_SN2" --instance-types m5.large \
  --scaling-config minSize=2,maxSize=4,desiredSize=2 --ami-type AL2_x86_64 \
  --labels role=system --no-cli-pager

aws eks create-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name app-nodes \
  --node-role "arn:aws:iam::${ACCOUNT_ID}:role/eks-node-role" \
  --subnets "$PRI_SN0" "$PRI_SN1" "$PRI_SN2" --instance-types m5.xlarge \
  --scaling-config minSize=3,maxSize=15,desiredSize=4 --ami-type AL2_x86_64 \
  --labels role=app --taints "key=dedicated,value=app,effect=NO_SCHEDULE" --no-cli-pager

aws eks wait nodegroup-active --cluster-name "$CLUSTER_NAME" --nodegroup-name system-nodes
aws eks wait nodegroup-active --cluster-name "$CLUSTER_NAME" --nodegroup-name app-nodes
kubectl get nodes -o wide
ok "Node groups ready"

step "28" "Install EKS addons + OIDC"
for ADDON in vpc-cni coredns kube-proxy aws-ebs-csi-driver; do
  aws eks create-addon --cluster-name "$CLUSTER_NAME" --addon-name "$ADDON" \
    --resolve-conflicts OVERWRITE --no-cli-pager 2>/dev/null || \
  aws eks update-addon --cluster-name "$CLUSTER_NAME" --addon-name "$ADDON" \
    --resolve-conflicts OVERWRITE --no-cli-pager
done
OIDC_URL=$(aws eks describe-cluster --name "$CLUSTER_NAME" \
  --query "cluster.identity.oidc.issuer" --output text)
OIDC_ID=$(echo "$OIDC_URL" | awk -F/ '{print $NF}')
aws iam create-open-id-connect-provider --url "$OIDC_URL" \
  --client-id-list sts.amazonaws.com \
  --thumbprint-list 9e99a48a9960b14926bb7f3b02e22da2b0ab7280 \
  --no-cli-pager 2>/dev/null || true
OIDC_PROVIDER="oidc.eks.${REGION}.amazonaws.com/id/${OIDC_ID}"
ok "Addons + OIDC ready: $OIDC_PROVIDER"

# ================================================================
# PHASE 9 — HELM ADDONS
# ================================================================
banner "PHASE 9 — Helm Addons"

step "29" "Add Helm repos + install ALB Controller"
helm repo add eks https://aws.github.io/eks-charts
helm repo add external-secrets https://charts.external-secrets.io
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add metrics-server https://kubernetes-sigs.github.io/metrics-server/
helm repo update

# ALB IRSA
aws iam create-role --role-name aws-load-balancer-controller-role \
  --assume-role-policy-document "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Principal\":{\"Federated\":\"arn:aws:iam::${ACCOUNT_ID}:oidc-provider/${OIDC_PROVIDER}\"},\"Action\":\"sts:AssumeRoleWithWebIdentity\",\"Condition\":{\"StringEquals\":{\"${OIDC_PROVIDER}:sub\":\"system:serviceaccount:kube-system:aws-load-balancer-controller\",\"${OIDC_PROVIDER}:aud\":\"sts.amazonaws.com\"}}}]}" \
  --no-cli-pager 2>/dev/null || true
aws iam attach-role-policy --role-name aws-load-balancer-controller-role \
  --policy-arn "arn:aws:iam::${ACCOUNT_ID}:policy/AWSLoadBalancerControllerIAMPolicy"

kubectl create serviceaccount aws-load-balancer-controller -n kube-system --dry-run=client -o yaml | kubectl apply -f -
kubectl annotate serviceaccount aws-load-balancer-controller -n kube-system \
  "eks.amazonaws.com/role-arn=arn:aws:iam::${ACCOUNT_ID}:role/aws-load-balancer-controller-role" --overwrite

SPOKE_VPC_ACTUAL=$(aws eks describe-cluster --name "$CLUSTER_NAME" \
  --query 'cluster.resourcesVpcConfig.vpcId' --output text)
helm upgrade --install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system --set clusterName="$CLUSTER_NAME" \
  --set serviceAccount.create=false --set serviceAccount.name=aws-load-balancer-controller \
  --set region="$REGION" --set vpcId="$SPOKE_VPC_ACTUAL" --wait
ok "ALB Controller installed"

step "30" "Install Metrics Server, External Secrets, Prometheus+Grafana"
helm upgrade --install metrics-server metrics-server/metrics-server \
  -n kube-system --set args[0]="--kubelet-insecure-tls" --wait

kubectl create namespace external-secrets --dry-run=client -o yaml | kubectl apply -f -
aws iam create-role --role-name external-secrets-role \
  --assume-role-policy-document "{\"Version\":\"2012-10-17\",\"Statement\":[{\"Effect\":\"Allow\",\"Principal\":{\"Federated\":\"arn:aws:iam::${ACCOUNT_ID}:oidc-provider/${OIDC_PROVIDER}\"},\"Action\":\"sts:AssumeRoleWithWebIdentity\",\"Condition\":{\"StringEquals\":{\"${OIDC_PROVIDER}:sub\":\"system:serviceaccount:external-secrets:external-secrets\",\"${OIDC_PROVIDER}:aud\":\"sts.amazonaws.com\"}}}]}" \
  --no-cli-pager 2>/dev/null || true
aws iam attach-role-policy --role-name external-secrets-role \
  --policy-arn "arn:aws:iam::${ACCOUNT_ID}:policy/ExternalSecretsPolicy"
helm upgrade --install external-secrets external-secrets/external-secrets -n external-secrets \
  --set installCRDs=true \
  --set "serviceAccount.annotations.eks\\.amazonaws\\.com/role-arn=arn:aws:iam::${ACCOUNT_ID}:role/external-secrets-role" \
  --wait

kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -
GRAFANA_PASS=$(openssl rand -base64 12 | tr -dc 'A-Za-z0-9' | head -c 14)
helm upgrade --install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
  -n monitoring --set grafana.adminPassword="$GRAFANA_PASS" \
  --set prometheus.prometheusSpec.retention=15d --wait
ok "All Helm addons installed  |  Grafana password: $GRAFANA_PASS"

# ================================================================
# PHASE 10 — DATA SERVICES: RDS + DocumentDB + MSK + Redis
# ================================================================
banner "PHASE 10 — Data Services"

step "31" "Create RDS PostgreSQL (Order Service DB)"
aws rds create-db-subnet-group --db-subnet-group-name rds-subnet-group \
  --db-subnet-group-description "RDS subnet group" \
  --subnet-ids "$DB_SN0" "$DB_SN1" "$DB_SN2" --no-cli-pager 2>/dev/null || true

aws rds create-db-instance \
  --db-instance-identifier prod-postgres \
  --db-instance-class db.r6g.large --engine postgres --engine-version "15.6" \
  --master-username orderadmin --master-user-password "$DB_PASSWORD" \
  --db-name orderdb --allocated-storage 100 --max-allocated-storage 1000 \
  --storage-type gp3 --storage-encrypted --multi-az \
  --db-subnet-group-name rds-subnet-group --vpc-security-group-ids "$RDS_SG" \
  --backup-retention-period 14 --deletion-protection \
  --no-publicly-accessible --no-cli-pager \
  --tags Key=Name,Value=prod-postgres Key=Service,Value=order-service
info "RDS creation started — waiting (~15 min)"
aws rds wait db-instance-available --db-instance-identifier prod-postgres
RDS_ENDPOINT=$(aws rds describe-db-instances --db-instance-identifier prod-postgres \
  --query 'DBInstances[0].Endpoint.Address' --output text)
ok "RDS endpoint: $RDS_ENDPOINT"

step "32" "Create DocumentDB cluster (Inventory Service — MongoDB compatible)"
aws docdb create-db-subnet-group --db-subnet-group-name docdb-subnet-group \
  --db-subnet-group-description "DocumentDB subnet group" \
  --subnet-ids "$DB_SN0" "$DB_SN1" "$DB_SN2" --no-cli-pager 2>/dev/null || true

aws docdb create-db-cluster \
  --db-cluster-identifier prod-docdb \
  --engine docdb --engine-version "7.0.0" \
  --master-username inventoryadmin --master-user-password "$MONGO_PASSWORD" \
  --db-subnet-group-name docdb-subnet-group \
  --vpc-security-group-ids "$DOCDB_SG" \
  --storage-encrypted --backup-retention-period 14 \
  --tags Key=Name,Value=prod-docdb Key=Service,Value=inventory-service \
  --no-cli-pager 2>/dev/null || true

aws docdb create-db-instance \
  --db-instance-identifier prod-docdb-1 \
  --db-cluster-identifier prod-docdb \
  --db-instance-class db.r6g.large --engine docdb \
  --no-cli-pager 2>/dev/null || true
info "DocumentDB creation started"

step "33" "Create Amazon MSK (Kafka cluster — 3 brokers)"
MSK_CLUSTER_ARN=$(aws kafka create-cluster-v2 \
  --cluster-name prod-msk \
  --provisioned '{
    "BrokerNodeGroupInfo": {
      "BrokerAZDistribution": "DEFAULT",
      "ClientSubnets": ["'"$MSK_SN0"'", "'"$MSK_SN1"'", "'"$MSK_SN2"'"],
      "InstanceType": "kafka.m5.large",
      "SecurityGroups": ["'"$MSK_SG"'"],
      "StorageInfo": {"EbsStorageInfo": {"VolumeSize": 100}}
    },
    "KafkaVersion": "3.6.0",
    "NumberOfBrokerNodes": 3,
    "EncryptionInfo": {
      "EncryptionInTransit": {"ClientBroker": "TLS", "InCluster": true}
    },
    "EnhancedMonitoring": "PER_BROKER"
  }' \
  --tags '{"Project": "platform", "Service": "messaging"}' \
  --query 'ClusterArn' --output text)
ok "MSK cluster creation started: $MSK_CLUSTER_ARN"
wait_msk "$MSK_CLUSTER_ARN"
MSK_BROKERS=$(aws kafka get-bootstrap-brokers --cluster-arn "$MSK_CLUSTER_ARN" \
  --query 'BootstrapBrokerStringTls' --output text)
ok "MSK brokers: $MSK_BROKERS"

step "34" "Create ElastiCache Redis cluster"
aws elasticache create-subnet-group \
  --cache-subnet-group-name redis-subnet-group \
  --cache-subnet-group-description "Redis subnet group" \
  --subnet-ids "$PRI_SN0" "$PRI_SN1" "$PRI_SN2" \
  --no-cli-pager 2>/dev/null || true

aws elasticache create-replication-group \
  --replication-group-id prod-redis \
  --description "Platform Redis cluster" \
  --num-cache-clusters 3 \
  --cache-node-type cache.r6g.large \
  --engine redis --engine-version "7.1" \
  --cache-subnet-group-name redis-subnet-group \
  --security-group-ids "$REDIS_SG" \
  --at-rest-encryption-enabled \
  --transit-encryption-enabled \
  --auth-token "$REDIS_TOKEN" \
  --automatic-failover-enabled \
  --multi-az-enabled \
  --no-cli-pager \
  --tags Key=Name,Value=prod-redis Key=Service,Value=caching
info "Redis creation started (~8 min)"
aws elasticache wait replication-group-available --replication-group-id prod-redis
REDIS_ENDPOINT=$(aws elasticache describe-replication-groups \
  --replication-group-id prod-redis \
  --query 'ReplicationGroups[0].NodeGroups[0].PrimaryEndpoint.Address' --output text)
ok "Redis endpoint: $REDIS_ENDPOINT"

# ================================================================
# PHASE 11 — SECRETS MANAGER
# ================================================================
banner "PHASE 11 — Secrets Manager (all credentials)"

step "35" "Store all secrets in AWS Secrets Manager"
for SECRET_NAME in \
  "prod/order-service/db:${DB_PASSWORD}" \
  "prod/inventory-service/mongodb:${MONGO_PASSWORD}" \
  "prod/redis/auth-token:${REDIS_TOKEN}"; do
  NAME="${SECRET_NAME%%:*}"
  VALUE="${SECRET_NAME##*:}"
  aws secretsmanager create-secret --name "$NAME" --secret-string "$VALUE" \
    --no-cli-pager 2>/dev/null || \
  aws secretsmanager update-secret --secret-id "$NAME" --secret-string "$VALUE" --no-cli-pager
  ok "  stored: $NAME"
done

# Store structured secrets
aws secretsmanager create-secret --name "prod/order-service/config" \
  --secret-string "{\"db_host\":\"${RDS_ENDPOINT}\",\"db_name\":\"orderdb\",\"db_user\":\"orderadmin\",\"kafka_brokers\":\"${MSK_BROKERS}\",\"redis_host\":\"${REDIS_ENDPOINT}\"}" \
  --no-cli-pager 2>/dev/null || \
aws secretsmanager update-secret --secret-id "prod/order-service/config" \
  --secret-string "{\"db_host\":\"${RDS_ENDPOINT}\",\"db_name\":\"orderdb\",\"db_user\":\"orderadmin\",\"kafka_brokers\":\"${MSK_BROKERS}\",\"redis_host\":\"${REDIS_ENDPOINT}\"}" \
  --no-cli-pager

ok "All secrets stored"

# ================================================================
# PHASE 12 — ECR + DOCKER IMAGES
# ================================================================
banner "PHASE 12 — ECR Repositories"

step "36" "Create ECR repos + login + build + push"
aws ecr get-login-password --region "$REGION" \
  | docker login --username AWS --password-stdin "$ECR"

for SVC in api-gateway svc-order svc-inventory; do
  aws ecr create-repository --repository-name "$SVC" \
    --image-scanning-configuration scanOnPush=true \
    --encryption-configuration encryptionType=AES256 \
    --no-cli-pager 2>/dev/null || true
  aws ecr put-lifecycle-policy --repository-name "$SVC" \
    --lifecycle-policy '{"rules":[{"rulePriority":1,"description":"Keep 10","selection":{"tagStatus":"any","countType":"imageCountMoreThan","countNumber":10},"action":{"type":"expire"}}]}' \
    --no-cli-pager
  if [ -d "./source/${SVC}" ]; then
    docker buildx build --platform linux/amd64 \
      --tag "${ECR}/${SVC}:1.0.0" --tag "${ECR}/${SVC}:latest" \
      --push "./source/${SVC}"
    ok "  pushed: ${ECR}/${SVC}:1.0.0"
  else
    info "  ./source/${SVC} not found — build and push manually"
  fi
done

# ================================================================
# PHASE 13 — CDN (CloudFront + S3)
# ================================================================
banner "PHASE 13 — CDN (CloudFront + S3 for MFEs)"

step "37" "Create S3 buckets for Shell + 2 MFEs + media"
for BUCKET in "shell-app-${ACCOUNT_ID}" "mfe-product-${ACCOUNT_ID}" "mfe-order-${ACCOUNT_ID}" "media-assets-${ACCOUNT_ID}"; do
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
    --create-bucket-configuration LocationConstraint="$REGION" 2>/dev/null || true
  aws s3api put-bucket-versioning --bucket "$BUCKET" \
    --versioning-configuration Status=Enabled
  aws s3api put-public-access-block --bucket "$BUCKET" \
    --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
  ok "  bucket: s3://$BUCKET"
done

step "38" "Create CloudFront OAC + distributions for each app"
OAC_ID=$(aws cloudfront create-origin-access-control \
  --origin-access-control-config \
    "Name=platform-oac,SigningProtocol=sigv4,SigningBehavior=always,OriginAccessControlOriginType=s3" \
  --query 'OriginAccessControl.Id' --output text 2>/dev/null || echo "existing")
ok "OAC: $OAC_ID"

for APP in "shell-app" "mfe-product" "mfe-order"; do
  BUCKET="${APP}-${ACCOUNT_ID}"
  CF_DOMAIN=$(aws cloudfront create-distribution \
    --distribution-config "{
      \"CallerReference\": \"${APP}-$(date +%s)\",
      \"Comment\": \"${APP} CDN\",
      \"DefaultCacheBehavior\": {
        \"TargetOriginId\": \"${BUCKET}\",
        \"ViewerProtocolPolicy\": \"redirect-to-https\",
        \"AllowedMethods\": {\"Quantity\": 2, \"Items\": [\"GET\",\"HEAD\"]},
        \"CachePolicyId\": \"658327ea-f89d-4fab-a63d-7e88639e58f6\",
        \"Compress\": true
      },
      \"Origins\": {\"Quantity\": 1, \"Items\": [{
        \"Id\": \"${BUCKET}\",
        \"DomainName\": \"${BUCKET}.s3.${REGION}.amazonaws.com\",
        \"S3OriginConfig\": {\"OriginAccessIdentity\": \"\"},
        \"OriginAccessControlId\": \"${OAC_ID}\"
      }]},
      \"Enabled\": true,
      \"HttpVersion\": \"http2and3\",
      \"PriceClass\": \"PriceClass_200\",
      \"WebACLId\": \"\"
    }" \
    --query 'Distribution.DomainName' --output text 2>/dev/null || echo "pending")
  ok "  CloudFront for ${APP}: https://${CF_DOMAIN}"
done

# ================================================================
# PHASE 14 — KUBERNETES MANIFESTS
# ================================================================
banner "PHASE 14 — Deploy Microservices to Kubernetes"

step "39" "Apply ClusterSecretStore"
kubectl apply -f - <<EOF
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: aws-secrets-manager
spec:
  provider:
    aws:
      service: SecretsManager
      region: ${REGION}
      auth:
        jwt:
          serviceAccountRef:
            name: external-secrets
            namespace: external-secrets
EOF

step "40" "Deploy API Gateway"
kubectl create namespace api-gateway --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-gateway
  namespace: api-gateway
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api-gateway
  template:
    metadata:
      labels:
        app: api-gateway
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8080"
        prometheus.io/path: "/actuator/prometheus"
    spec:
      tolerations:
        - key: dedicated
          value: app
          effect: NoSchedule
      containers:
        - name: api-gateway
          image: ${ECR}/api-gateway:1.0.0
          ports:
            - containerPort: 8080
          env:
            - name: REDIS_HOST
              value: "${REDIS_ENDPOINT}"
            - name: JWT_SECRET
              valueFrom:
                secretKeyRef:
                  name: platform-secrets
                  key: jwt-secret
          resources:
            requests:
              cpu: 250m
              memory: 512Mi
            limits:
              cpu: 1000m
              memory: 1Gi
          livenessProbe:
            httpGet:
              path: /actuator/health/liveness
              port: 8080
            initialDelaySeconds: 30
          readinessProbe:
            httpGet:
              path: /actuator/health/readiness
              port: 8080
            initialDelaySeconds: 15
          securityContext:
            allowPrivilegeEscalation: false
            runAsNonRoot: true
            runAsUser: 1000
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          volumeMounts:
            - name: tmp
              mountPath: /tmp
      volumes:
        - name: tmp
          emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: api-gateway
  namespace: api-gateway
spec:
  type: ClusterIP
  selector:
    app: api-gateway
  ports:
    - port: 80
      targetPort: 8080
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: api-gateway-hpa
  namespace: api-gateway
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: api-gateway
  minReplicas: 3
  maxReplicas: 20
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
EOF

step "41" "Deploy Order Service"
kubectl create namespace order-service --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f - <<EOF
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: order-service-secrets
  namespace: order-service
spec:
  refreshInterval: "1h"
  secretStoreRef:
    kind: ClusterSecretStore
    name: aws-secrets-manager
  target:
    name: order-service-secrets
    creationPolicy: Owner
  data:
    - secretKey: DB_HOST
      remoteRef:
        key: prod/order-service/config
        property: db_host
    - secretKey: DB_PASSWORD
      remoteRef:
        key: prod/order-service/db
    - secretKey: KAFKA_BROKERS
      remoteRef:
        key: prod/order-service/config
        property: kafka_brokers
    - secretKey: REDIS_HOST
      remoteRef:
        key: prod/order-service/config
        property: redis_host
    - secretKey: REDIS_PASSWORD
      remoteRef:
        key: prod/redis/auth-token
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: order-service
  namespace: order-service
spec:
  replicas: 2
  selector:
    matchLabels:
      app: order-service
  template:
    metadata:
      labels:
        app: order-service
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8081"
        prometheus.io/path: "/actuator/prometheus"
    spec:
      tolerations:
        - key: dedicated
          value: app
          effect: NoSchedule
      containers:
        - name: order-service
          image: ${ECR}/svc-order:1.0.0
          ports:
            - containerPort: 8081
          envFrom:
            - secretRef:
                name: order-service-secrets
          env:
            - name: DB_NAME
              value: orderdb
            - name: DB_USER
              value: orderadmin
          resources:
            requests:
              cpu: 500m
              memory: 1Gi
            limits:
              cpu: 2000m
              memory: 2Gi
          livenessProbe:
            httpGet:
              path: /actuator/health/liveness
              port: 8081
            initialDelaySeconds: 60
          readinessProbe:
            httpGet:
              path: /actuator/health/readiness
              port: 8081
            initialDelaySeconds: 30
          securityContext:
            allowPrivilegeEscalation: false
            runAsNonRoot: true
            runAsUser: 1000
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          volumeMounts:
            - name: tmp
              mountPath: /tmp
      volumes:
        - name: tmp
          emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: order-service
  namespace: order-service
spec:
  type: ClusterIP
  selector:
    app: order-service
  ports:
    - port: 80
      targetPort: 8081
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: order-service-hpa
  namespace: order-service
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: order-service
  minReplicas: 2
  maxReplicas: 15
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
EOF

step "42" "Deploy Inventory Service"
kubectl create namespace inventory-service --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: inventory-service
  namespace: inventory-service
spec:
  replicas: 2
  selector:
    matchLabels:
      app: inventory-service
  template:
    metadata:
      labels:
        app: inventory-service
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8082"
    spec:
      tolerations:
        - key: dedicated
          value: app
          effect: NoSchedule
      containers:
        - name: inventory-service
          image: ${ECR}/svc-inventory:1.0.0
          ports:
            - containerPort: 8082
          env:
            - name: SPRING_DATA_MONGODB_URI
              value: "mongodb://inventoryadmin:${MONGO_PASSWORD}@prod-docdb.cluster-${ACCOUNT_ID}.${REGION}.docdb.amazonaws.com:27017/inventorydb?ssl=true&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false"
            - name: KAFKA_BROKERS
              value: "${MSK_BROKERS}"
            - name: REDIS_HOST
              value: "${REDIS_ENDPOINT}"
          resources:
            requests:
              cpu: 500m
              memory: 1Gi
            limits:
              cpu: 2000m
              memory: 2Gi
          livenessProbe:
            httpGet:
              path: /actuator/health/liveness
              port: 8082
            initialDelaySeconds: 60
          readinessProbe:
            httpGet:
              path: /actuator/health/readiness
              port: 8082
            initialDelaySeconds: 30
          securityContext:
            allowPrivilegeEscalation: false
            runAsNonRoot: true
            runAsUser: 1000
            readOnlyRootFilesystem: true
            capabilities:
              drop: ["ALL"]
          volumeMounts:
            - name: tmp
              mountPath: /tmp
      volumes:
        - name: tmp
          emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: inventory-service
  namespace: inventory-service
spec:
  type: ClusterIP
  selector:
    app: inventory-service
  ports:
    - port: 80
      targetPort: 8082
EOF

step "43" "Apply ALB Ingress (WAF + TLS + routing)"
kubectl apply -f - <<EOF
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: platform-ingress
  namespace: api-gateway
  annotations:
    kubernetes.io/ingress.class: alb
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTPS":443},{"HTTP":80}]'
    alb.ingress.kubernetes.io/ssl-redirect: "443"
    alb.ingress.kubernetes.io/certificate-arn: "${INPUT_CERT_ARN}"
    alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-TLS13-1-2-2021-06
    alb.ingress.kubernetes.io/wafv2-acl-arn: "${WAF_ACL}"
    alb.ingress.kubernetes.io/load-balancer-attributes: "deletion_protection.enabled=true"
    alb.ingress.kubernetes.io/healthcheck-path: /actuator/health/readiness
spec:
  rules:
    - host: "api.${DOMAIN}"
      http:
        paths:
          - path: /api
            pathType: Prefix
            backend:
              service:
                name: api-gateway
                port:
                  number: 80
EOF

# ================================================================
# PHASE 15 — KAFKA TOPICS
# ================================================================
banner "PHASE 15 — Create Kafka Topics"

step "44" "Create Kafka topics in MSK"
info "Creating Kafka topics (requires MSK to be fully ready)"
KAFKA_TOOL_POD=$(kubectl run kafka-admin --image=bitnami/kafka:3.6 \
  --restart=Never --env="KAFKA_BROKERS=${MSK_BROKERS}" \
  --command -- sleep 300 --dry-run=client -o name 2>/dev/null || echo "manual")

for TOPIC_CONFIG in \
  "order.created:3:3:604800000" \
  "order.updated:3:3:604800000" \
  "order.cancelled:3:3:604800000" \
  "inventory.reserved:3:3:604800000" \
  "inventory.updated:3:3:259200000" \
  "stock.alert:1:3:259200000"; do
  TOPIC="${TOPIC_CONFIG%%:*}"
  info "  Topic: $TOPIC"
done
info "To create topics, run from inside VPC:"
info "  kafka-topics.sh --bootstrap-server \$MSK_BROKERS --create --topic order.created --partitions 3 --replication-factor 3"

# ================================================================
# COMPLETE
# ================================================================
banner "DEPLOYMENT COMPLETE"

step "45" "Verify all deployments"
kubectl rollout status deployment/api-gateway -n api-gateway --timeout=300s
kubectl rollout status deployment/order-service -n order-service --timeout=300s
kubectl rollout status deployment/inventory-service -n inventory-service --timeout=300s

ALB_DNS=$(kubectl get ingress platform-ingress -n api-gateway \
  -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null \
  || echo "pending — run: kubectl get ingress -A")

echo ""
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " PLATFORM DEPLOYMENT COMPLETE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "  EKS Cluster    : $CLUSTER_NAME"
echo "  Region         : $REGION"
echo "  Hub VPC        : $HUB_VPC_ID"
echo "  Spoke VPC      : $SPOKE_VPC_ID"
echo "  Transit GW     : $TGW_ID"
echo "  RDS PostgreSQL : $RDS_ENDPOINT"
echo "  MSK Kafka      : $MSK_BROKERS"
echo "  Redis          : $REDIS_ENDPOINT"
echo "  WAF ACL        : $WAF_ACL"
echo "  ALB DNS        : $ALB_DNS"
echo "  Grafana Pass   : $GRAFANA_PASS"
echo ""
echo "  APIs:"
echo "    https://api.${DOMAIN}/api/products        → Inventory Service"
echo "    https://api.${DOMAIN}/api/orders          → Order Service"
echo "    https://api.${DOMAIN}/api/cart            → Order Service"
echo "    https://api.${DOMAIN}/api/auth/login      → Auth endpoint"
echo ""
echo "  Frontend CDNs:"
echo "    Shell App     → s3://shell-app-${ACCOUNT_ID}"
echo "    MFE Product   → s3://mfe-product-${ACCOUNT_ID}"
echo "    MFE Order     → s3://mfe-order-${ACCOUNT_ID}"
echo ""
echo "  Useful commands:"
echo "    kubectl get pods -A"
echo "    kubectl get hpa -A"
echo "    kubectl get ingress -A"
echo "    kubectl logs -n order-service -l app=order-service --tail=50"
echo ""
echo -e "${YELLOW}  IMPORTANT: Enable Shield Advanced protection on your ALB and CloudFront${NC}"
echo "    aws shield create-protection --name api-alb --resource-arn <ALB_ARN>"
echo ""
